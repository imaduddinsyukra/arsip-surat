<footer class="sticky-footer">
    <div class="container">
        <div class="text-center">
            <small>Copyright © 2020 Sistem Informasi Pengarsipan Surat SMK Muhammadiyah 3 Pekanbaru</small>
        </div>
    </div>
</footer>