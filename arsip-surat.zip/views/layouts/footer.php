<footer class="sticky-footer">
    <div class="container">
        <div class="text-center">
            <small>Copyright © 2020 Sistem Informasi Perkantoran Berbasis Elektronik Tualang Mandau</small>
        </div>
    </div>
</footer>