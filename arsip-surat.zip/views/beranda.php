<div class="content-wrapper">
    <div class="container-fluid">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Beranda</a>
        </li>
      </ol>
      <!-- Example DataTables Card-->
      <div class="card mb-3">
        <div class="card-header">
          <i class="fa fa-table"></i> Halaman Beranda</div>
        <div class="card-body">
          <div class="table-responsive">
              <p align="center">Selamat Datang <b><u><?= $_SESSION['nama'];?></u></b> Di Sistem Informasi Pengarsipan Surat SMK Muhammadiyah 3 Pekanbaru
              </p>
          </div>
        </div>
        
      </div>
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->